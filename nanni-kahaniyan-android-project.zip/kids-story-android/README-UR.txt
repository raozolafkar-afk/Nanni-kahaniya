ننھی کہانیاں — Android APK بنانے کا پروجیکٹ

اہم: یہ Android پروجیکٹ ہے، ابھی APK فائل نہیں ہے۔ APK بنانے کے لیے GitHub Actions استعمال ہوگا۔

موبائل سے APK بنانے کے مراحل:
1) GitHub.com پر اپنا اکاؤنٹ بنائیں یا سائن اِن کریں۔
2) New repository بنائیں، نام nanni-kahaniyan رکھیں اور Public منتخب کریں۔
3) اس ZIP کو کمپیوٹر پر کھول کر اس کے اندر موجود تمام فائلیں repository میں اپ لوڈ کریں۔ فولڈر کے اندر کی فائلیں اپ لوڈ کریں، ZIP کو بطور ایک فائل نہیں۔
4) repository میں Actions کھولیں۔ اگر workflow فعال کرنے کا پیغام آئے تو اسے فعال کریں۔
5) بائیں طرف Build Android APK منتخب کریں، پھر Run workflow دبائیں۔
6) Build مکمل ہونے پر اسی run کے نیچے Artifacts میں Nanni-Kahaniyan-APK ڈاؤن لوڈ کریں۔
7) ZIP کھولیں، app-debug.apk نکالیں، Android میں اسے کھولیں اور اجازت دے کر Install کریں۔

نوٹ: یہ Debug APK ہے، ذاتی ٹیسٹ/انسٹال کے لیے۔ Play Store پر شائع کرنے کے لیے الگ signed release درکار ہے۔
